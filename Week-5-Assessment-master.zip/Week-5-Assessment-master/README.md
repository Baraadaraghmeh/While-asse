# Week-5-Assessment

## Instructions

- Estimated time 1 hour.
- There are 4 questions only.
- Don't forget to manage your time.
- Use the main.js file.
- Don't look to your previous code
- You have MDN only as a resource and you can use the console to check your code.
- Please put your code under => WRITE YOUR CODE UNDER THIS LINE.
- Don't forget to write the parameters (arguments) if the question needs them.

GOOD LUCK 👩‍💻 👨‍💻
